# 🎰 Kazino Bot - O'yin Boti

Telegram uchun interaktiv o'yin boti. Foydalanuvchilar guruhlarda son topish o'yinini o'ynashlari mumkin.

## ✨ Xususiyatlar

- ✅ Majburiy kanal obunasi
- 🌐 3 tilli interfeys (O'zbekcha, Ruscha, Inglizcha)
- 🎮 Guruhda son topish o'yini (bir nechta son)
- 👤 Shaxsiy kabinet va statistika
- ⚙️ To'liq admin panel (faqat admin uchun)
- 📢 Kanallarni boshqarish
- 📊 Foydalanuvchilar statistikasi
- 🆘 Admin bilan bog'lanish
- 🎲 Tasodifiy son generatori
- 🏆 G'oliblarni e'lon qilish
- 💾 Ma'lumotlarni saqlash (JSON faylda)
- 📤 Broadcast tizimi (matn, media, forward)

## 📋 O'rnatish

1. **Node.js o'rnating:**
   - Node.js 18+ versiyasi kerak
   - [nodejs.org](https://nodejs.org) dan yuklab oling

2. **Kerakli kutubxonalarni o'rnating:**
\`\`\`bash
npm install
\`\`\`

3. **Bot tokenini oling:**
   - Telegram'da [@BotFather](https://t.me/BotFather) ga o'ting
   - `/newbot` komandasi bilan yangi bot yarating
   - Olingan tokenni nusxalang

4. **Environment o'zgaruvchilarini sozlang:**
   - `.env.example` faylini `.env` ga nusxalang
   - `BOT_TOKEN` ni o'z tokeningiz bilan almashtiring
   - `ADMIN_ID` ni o'z Telegram ID ingiz bilan almashtiring

5. **Telegram ID ni topish:**
   - [@userinfobot](https://t.me/userinfobot) ga `/start` yuboring
   - Sizning ID ingizni ko'rsatadi

## 🚀 Ishga tushirish

### Lokal kompyuterda:
\`\`\`bash
npm start
\`\`\`

### Development mode (auto-restart):
\`\`\`bash
npm run dev
\`\`\`

### Serverda (masalan, VPS):
\`\`\`bash
# PM2 ishlatish tavsiya etiladi
npm install -g pm2
pm2 start bot.js --name kazino-bot
pm2 save
pm2 startup

# Loglarni ko'rish
pm2 logs kazino-bot

# Qayta ishga tushirish
pm2 restart kazino-bot

# To'xtatish
pm2 stop kazino-bot
\`\`\`

### Systemd service sifatida (Linux):
\`\`\`bash
# /etc/systemd/system/kazino-bot.service yarating
sudo nano /etc/systemd/system/kazino-bot.service
\`\`\`

Service fayl:
\`\`\`ini
[Unit]
Description=Kazino Telegram Bot
After=network.target

[Service]
Type=simple
User=your_username
WorkingDirectory=/path/to/bot
Environment="BOT_TOKEN=your_token"
Environment="ADMIN_ID=your_id"
ExecStart=/usr/bin/node bot.js
Restart=always

[Install]
WantedBy=multi-user.target
\`\`\`

Ishga tushirish:
\`\`\`bash
sudo systemctl enable kazino-bot
sudo systemctl start kazino-bot
sudo systemctl status kazino-bot
\`\`\`

## 📖 Foydalanish

### Foydalanuvchilar uchun:

1. **Botni boshlash:**
   - `/start` komandasi bilan botni ishga tushiring
   - Tilni tanlang (O'zbekcha, Ruscha yoki Inglizcha)
   - Barcha kanallarga obuna bo'ling
   - "Obunani Tekshirish" tugmasini bosing

2. **O'yin boshlash:**
   - "🕹 O'yin Boshlash" tugmasini bosing
   - Guruh linkini yuboring (bot guruhda admin bo'lishi kerak)
   - Maksimal sonni kiriting (masalan: 100)
   - Bot nechta son o'ylashi kerakligini kiriting (masalan: 5)
   - Guruhda o'yin boshlanadi!

3. **O'yin o'ynash:**
   - Guruhda son yozing
   - Bot "XATO" yoki "WIN" deb javob beradi
   - To'g'ri topgan kishi g'olib!
   - Barcha sonlar topilgunga qadar o'yin davom etadi

4. **Kabinet:**
   - "👤 Kabinet" tugmasini bosing
   - Shaxsiy ma'lumotlar va statistikangizni ko'ring

5. **Tilni o'zgartirish:**
   - Asosiy menyuda "🌐 Tilni O'zgartirish" tugmasini bosing
   - Yangi tilni tanlang
   - Til sozlamasi saqlanib qoladi

6. **Yordam olish:**
   - "🆘 SOS" tugmasini bosing
   - Admin yoki Dasturchi bilan bog'laning

### Admin uchun:

1. **Admin panel:**
   - Faqat admin ID ga ega foydalanuvchi ko'radi
   - "⚙️ Admin Panel" tugmasini bosing

2. **Statistika:**
   - Jami foydalanuvchilar soni
   - Jami o'yinlar va g'alabalar
   - Faol o'yinlar soni
   - Majburiy kanallar soni

3. **Xabar yuborish (Broadcast):**
   - Barcha foydalanuvchilarga xabar yuborish
   - Matn, rasm, video, audio yuborish mumkin
   - Kanaldan yoki guruhdan forward qilish mumkin
   - Muvaffaqiyatli va xato bo'lgan yuborishlar soni

4. **Kanallar boshqaruvi:**
   - Majburiy kanallarni ko'rish
   - Yangi kanal qo'shish
   - Kanalni o'chirish
   - O'zgarishlar avtomatik saqlanadi

5. **Foydalanuvchilar ro'yxati:**
   - Barcha foydalanuvchilar ID si
   - Har birining o'yinlar va g'alabalar soni

6. **Faol o'yinlar:**
   - Hozirda qaysi guruhlarda o'yin borligini ko'rish
   - O'yin ma'lumotlari

## ⚙️ Sozlamalar

### Environment Variables

`.env` faylida:
\`\`\`env
BOT_TOKEN=your_bot_token_here
ADMIN_ID=123456789
\`\`\`

### Ma'lumotlar saqlash

Bot quyidagi fayllarni yaratadi va ishlatadi:
- `channels.json` - Majburiy kanallar ro'yxati
- `users.json` - Foydalanuvchilar ro'yxati
- `stats.json` - Foydalanuvchilar statistikasi
- `user_prefs.json` - Foydalanuvchi sozlamalari (til)

**Muhim:** Bu fayllar avtomatik yaratiladi va bot qayta ishga tushganda ham saqlanib qoladi.

## 🛠 Texnik ma'lumotlar

- **Til:** Node.js 18+
- **Kutubxona:** Telegraf 4.16+
- **Arxitektura:** Session-based conversation handling
- **Ma'lumotlar saqlash:** JSON fayllarda
- **Qo'llab-quvvatlanadigan tillar:** O'zbekcha, Ruscha, Inglizcha

## 🔒 Xavfsizlik

- Admin ID environment variable orqali sozlanadi
- Faqat admin admin panelga kirishi mumkin
- Bot tokeni `.env` faylida saqlanadi (git'ga yuklanmaydi)
- Barcha xatolar log'ga yoziladi

## 🐛 Muammolarni hal qilish

### Bot ishlamayapti:
1. `BOT_TOKEN` to'g'ri kiritilganligini tekshiring
2. Internet aloqasi borligini tekshiring
3. Bot @BotFather da yaratilganligini tekshiring
4. Node.js versiyasi 18+ ekanligini tekshiring

### Admin panel ko'rinmayapti:
1. `ADMIN_ID` to'g'ri kiritilganligini tekshiring
2. O'z Telegram ID ingizni [@userinfobot](https://t.me/userinfobot) orqali tekshiring
3. Botni qayta ishga tushiring

### Kanallar saqlanmayapti:
1. Fayl yozish huquqlari borligini tekshiring
2. Disk bo'sh joyini tekshiring
3. JSON fayllar buzilmaganligini tekshiring

### O'yin guruhda ishlamayapti:
1. Bot guruhda admin ekanligini tekshiring
2. Bot xabar yuborish huquqiga ega ekanligini tekshiring
3. Guruh username to'g'ri kiritilganligini tekshiring

### Til sozlamalari saqlanmayapti:
1. `user_prefs.json` fayli yaratilganligini tekshiring
2. Fayl yozish huquqlari borligini tekshiring

## 📝 Eslatmalar

- Bot guruhda admin bo'lishi shart
- Har bir guruhda faqat bitta o'yin bo'lishi mumkin
- Ma'lumotlar JSON fayllarida saqlanadi
- Serverda ishlatish uchun PM2 yoki systemd tavsiya etiladi
- Til sozlamalari foydalanuvchi uchun saqlanib qoladi
- Broadcast tizimi media va forward qilingan xabarlarni qo'llab-quvvatlaydi

## 🤝 Yordam

Muammolar yoki savollar bo'lsa:
- Telegram: [@MamurZokirov](https://t.me/MamurZokirov)

## 📄 Litsenziya

Bu loyiha shaxsiy foydalanish uchun yaratilgan.

---

**Omad! 🎰🎉**
